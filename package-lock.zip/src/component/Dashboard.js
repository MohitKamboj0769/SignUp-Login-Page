import React from 'react'
import './Dashboard.css'
function Dashboard() {
  return (
    <div className='divv3'>
      <h1 className='high'>Welcome to this page </h1>
      

    </div>
  )
}

export default Dashboard